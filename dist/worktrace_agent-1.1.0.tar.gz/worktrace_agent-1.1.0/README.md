# WorkTraceAgent

WorkTraceAgent 以只读方式汇总多种 Coding Agent 的本机会话，生成可回溯、OKR 优先的中文工程日报与周报，并在基础报告冻结后追加独立网页研究的“外部拓展（非工作证据）”。

采集、归一化、脱敏和拼接全部由 Python 完成。进入 `brief-context.md` 的每条已接受对话消息都会完整保留，不做摘要、抽样、单消息截断或“只留最近几条”；短消息（如“继续”）也不会丢弃。消息以 JSON 字符串写入，换行可逆保留。密钥、凭据、私人绝对路径、系统/开发者指令和 thinking/reasoning 仍按安全边界排除或脱敏。

## 支持范围

- 专用解析：Codex CLI/Desktop、Claude Code、Qoder、CodeBuddy。
- Portable profiles：ZCode、Trae、通义灵码、Comate、Kimi CLI/Code、Qwen Code、Gemini CLI、OpenCode、GitHub Copilot、Cline、Roo Code、Windsurf、Factory Droid。
- 自定义产品：在用户配置中声明产品级 JSON、JSONL 或 SQLite transcript 根目录与 pattern，无需改代码。

具体路径、支持等级和保守降级规则见 [references/connectors.md](references/connectors.md)。产品格式变化时以 `coverage.md` 为准；`partial`、`empty`、`missing` 和 `error` 都不等于完整覆盖。

## 快速开始

直接从源码运行：

```bash
python3 scripts/worktrace.py setup
python3 scripts/worktrace.py run --day today --research auto
python3 scripts/worktrace.py weekly --week this-week --research auto
```

周报生成会先识别本机可执行的 Coding Agent，再按该周采集到的消息数选择使用频率最高的已启用 Agent；同频时优先配置的低成本档位。内置生成适配器包括 Codex、Claude Code 和 Gemini CLI，默认低成本模型分别为 `gpt-5.4-mini`、`haiku`、`gemini-2.5-flash`。可显式覆盖：

```bash
python3 scripts/worktrace.py weekly --week this-week --agent codex --model gpt-5.4-mini
python3 scripts/worktrace.py weekly --week this-week --agent claude --model haiku
```

`--agent` 不可用时会失败而非静默换 Agent；`generation-selection.json` 记录最终 Agent、模型、周期消息量和选择原因。报告模型的 `--model` 与联网拓展的 `--research-model` 相互独立。详细选择算法和任意 CLI 接入方法见 [references/generation.md](references/generation.md)。

若全文超过低成本模型的单次上下文，Python 只按完整 `E-` 证据块做无损分片，不生成摘要；同一个已选 Agent 逐片接收全部原文并产出候选，最后再归并为周报。分片原文与候选保存在私有 `generation-chunks/`，`generation-selection.json` 记录分片数。单条消息本身超过上限时直接失败，不截断。

也可以安装为普通 Python CLI：

```bash
python3 -m pip install .
worktrace setup
worktrace run --day today --research auto
```

核心采集与报告链路支持 Python 3.9+；内置 `schedule` 命令当前使用 macOS `launchd`，其它系统请用系统自身的定时器调用同一 CLI。

没有受支持的本地生成 CLI 时使用 `--no-model` 生成宿主无关的 prompt 与 JSON Schema，让当前 Coding Agent 合成 JSON，再用匹配的 `brief-context.md` 和 `signals.json` 执行 `finalize`。完整宿主流程见 [SKILL.md](SKILL.md)。

## 报告与研究边界

- 每条工作事实引用经过原始 TraceBundle 重算认证的 `E-xxxxxxxxxxxx` 锚点。
- 上下文默认不限字符数；若用户配置 `context.max_chars > 0`，超过硬上限会直接失败，绝不截断或省略对话。
- 周报重新扫描整周证据，不拼接历史日报；覆盖、最终状态、风险、下周行动和跨证据工作模式分别校验。
- 基础报告生成时关闭网页和本地工具；拓展阶段只接收脱敏公共技术主题，并仅开启网页检索。
- 外部拓展优先官方文档、标准、论文和原始发布；AI HOT 只作公开只读发现源，未回到一手来源时必须标为 `discovery_only` / `partial`。

## 隐私与安全

默认不读取凭据、认证数据库、浏览器缓存、thinking/reasoning 或加密数据；密钥、带凭据 URL、会话标识和私人绝对路径会在进入模型前脱敏。联网前应把无法自动识别的客户名和私有项目名加入 `research.private_terms`。

产物默认写入 `~/.local/state/worktrace-agent/artifacts`，目录权限为 `0700`、文件为 `0600`。保留策略只清理由 WorkTrace 标记的过期周期目录。

## 验证

```bash
python3 -m unittest discover -s tests -v
python3 -m compileall -q scripts tests
```
