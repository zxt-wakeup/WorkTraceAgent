# 周报生成 Agent 选择与迁移

## 自动选择

`draft`、`run` 和 `weekly` 在模型调用前读取匹配周期的 `signals.json`：

1. 用 `shutil.which` 检查 `generation.runners` 中已启用 CLI 是否真实存在。
2. 按 runner 的 `origins` 汇总本周期已接受消息数；会话数、文件数和历史总量不参与排序。
3. 选择消息数最多的本机候选；同频时选择较小的 `cost_rank`，再按 runner key 稳定排序。
4. `--agent` 是严格覆盖，未知、禁用或未安装都会失败。`--model` 优先于全局和 runner 默认模型。
5. 把 agent、adapter、model、usage_messages、cost_rank 和 reason 写入 `generation-selection.json`。

默认低成本档位为：Codex `gpt-5.4-mini`、Claude Code `haiku`、Gemini CLI `gemini-2.5-flash`。模型可用性和实际费用取决于用户账户与 CLI 版本；用 `--model` 或用户级 settings 更新，不在代码中推断订阅价格。

## 配置

```json
{
  "generation": {
    "agent": "auto",
    "model": "",
      "timeout_seconds": 900,
      "chunk_chars": 250000,
    "runners": {
      "codex_cli": {
        "enabled": true,
        "command": "codex",
        "adapter": "codex",
        "model": "gpt-5.4-mini",
        "cost_rank": 10,
        "origins": ["codex", "codex_cli"]
      }
    }
  }
}
```

内置 `codex`、`claude`、`gemini` adapter 以 stdin 传入全文 prompt，在临时空工作区运行并禁用本地/网页工具；只复制对应 CLI 的最小认证文件或允许的 API Key 环境变量，不加载项目规则。

## 接入其它 Coding Agent CLI

CLI 若能从 stdin 接收 prompt，并把最终 JSON 输出到 stdout，可配置 `generic` adapter：

```json
{
  "generation": {
    "runners": {
      "my_agent": {
        "enabled": true,
        "command": "my-agent",
        "adapter": "generic",
        "args": ["run", "--model", "{model}"],
        "response_field": "",
        "env_allowlist": ["MY_AGENT_API_KEY"],
        "model": "vendor-cheap-model",
        "cost_rank": 15,
        "origins": ["my_agent"]
      }
    }
  }
}
```

`{model}` 与 `{schema}` 可用于参数模板。若 stdout 是 JSON wrapper，把 `response_field` 配为点分字段（如 `result`）；为空时 stdout 本身必须是报告 JSON。Generic runner 只继承基础网络/语言环境以及显式 `env_allowlist`，不继承任意项目变量。若产品不能通过 stdin/stdout 完成无工具单轮调用，使用 `--no-model` 的 host-native 流程，不要用 shell 拼接全文参数。

## 全文与上下文限制

Python 不做摘要、抽样或消息截断。`context.max_chars` 默认 `0`（不限）；正数只作为硬失败阈值，绝不改变文本。若 CLI/模型拒绝全文，换用更大上下文模型、缩短报告周期或由用户调整采集范围；不得自动丢弃旧消息、工具输出或短消息。

当完整 prompt 超过 `generation.chunk_chars` 时，Python 只沿会话和完整 `E-` 证据块边界切分；同一个已选 runner 逐片读取全部原文、生成候选报告，最后再做一次候选归并。每个原始锚点只进入一个分片，公共证据规则可以重复；分片 prompt/候选写入私有 `generation-chunks/`。若单条完整消息仍超限则失败。这个阶段不改变 `brief-context.md`，也不允许 Python 生成内容摘要。

升级兼容：旧版默认组合 `max_chars=400000`、`per_message_chars=12000` 会在读取时迁移为不限模式，避免历史默认继续截断；其它用户显式正数仍保留为硬失败阈值。
